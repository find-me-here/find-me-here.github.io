/*
 * Runs on Mero Page itself (see manifest.json), so the site's /captures/extension page can tell whether the extension is
 * here and hand it a token. The page and this script talk on the page's own window; the shapes are the site's
 * `lib/extensionBridge.ts` — keep them in step. A classic script, not a module: content scripts can't be modules.
 */
(() => {
  const CHANNEL = "meropage-extension";

  const post = (message) => window.postMessage({ channel: CHANNEL, from: "extension", ...message }, location.origin);

  const ask = (message) =>
    chrome.runtime.sendMessage(message).then(
      (answer) => answer ?? { ok: false, message: "The extension didn’t answer." },
      (error) => ({ ok: false, message: error.message }),
    );

  async function sendStatus() {
    const answer = await ask({ type: "status" });
    if (answer.ok) post({ type: "status", connected: answer.connected, email: answer.email, version: answer.version });
  }

  window.addEventListener("message", async (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    const data = event.data;
    if (!data || data.channel !== CHANNEL || data.from !== "page") return;

    if (data.type === "hello") {
      await sendStatus();
    } else if (data.type === "connect") {
      const answer = await ask({ type: "connect", token: data.token, api: data.api });
      post(answer.ok ? { type: "connected", email: answer.email } : { type: "error", message: answer.message });
    }
  });

  // For a page that was already listening; one that mounts later says hello.
  void sendStatus();
})();
