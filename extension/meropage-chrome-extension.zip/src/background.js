/**
 * The extension's service worker: the right-click menus ("Save this page / link / selection to Mero Page") and the Connect
 * handshake with the site's /captures/extension page, which arrives through src/bridge.js. The popup saves on its own.
 */
import { SignedOut, connect, getAccount, saveCapture, siteAddress } from "./account.js";
import { cleanLink, newCapture, pageDetails, readPage, readPost } from "./capture.js";
import { isBridgeSite } from "./config.js";

const CONNECT_PATH = "/captures/extension/";
const DEFAULT_TITLE = "Save to Mero Page";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "save-page", title: "Save this page to Mero Page", contexts: ["page"] });
    chrome.contextMenus.create({ id: "save-link", title: "Save link to Mero Page", contexts: ["link"] });
    chrome.contextMenus.create({ id: "save-selection", title: "Save selection to Mero Page", contexts: ["selection"] });
  });
});

/** Runs `func` in the tab. Null where Chrome lets no extension read the page (chrome://, the Web Store, a PDF). */
async function inPage(tabId, func, args = []) {
  try {
    const [result] = await chrome.scripting.executeScript({ target: { tabId }, func, args });
    return result?.result ?? null;
  } catch {
    return null;
  }
}

/** A tick or a cross on the toolbar icon for a moment: the only answer a right-click save gets. */
function flash(tabId, ok, title) {
  chrome.action.setBadgeBackgroundColor({ tabId, color: ok ? "#0f766e" : "#dc2626" });
  chrome.action.setBadgeText({ tabId, text: ok ? "✓" : "!" });
  chrome.action.setTitle({ tabId, title });
  setTimeout(() => {
    chrome.action.setBadgeText({ tabId, text: "" });
    chrome.action.setTitle({ tabId, title: DEFAULT_TITLE });
  }, 2500);
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;
  if (!(await getAccount())) {
    chrome.tabs.create({ url: await siteAddress(CONNECT_PATH) });
    return;
  }
  try {
    const page = pageDetails(await inPage(tab.id, readPage), tab);
    let capture;
    if (info.menuItemId === "save-link") {
      // In a feed, the link right-clicked is usually a post's time stamp: the post's text comes with it where it can be found.
      capture = newCapture({ url: cleanLink(info.linkUrl), text: await inPage(tab.id, readPost, [info.linkUrl]), pageUrl: page.url });
    } else if (info.menuItemId === "save-selection") {
      capture = newCapture({ ...page, url: cleanLink(page.url), text: page.text ?? info.selectionText, pageUrl: page.url });
    } else {
      capture = newCapture({ ...page, url: cleanLink(page.url), pageUrl: page.url });
    }
    await saveCapture(capture);
    flash(tab.id, true, "Saved to your Mero Page Captures");
  } catch (error) {
    if (error instanceof SignedOut) chrome.tabs.create({ url: await siteAddress(CONNECT_PATH) });
    flash(tab.id, false, error.message);
  }
});

/** Messages from src/bridge.js — only from the site, and a token only from its Connect page. */
async function handle(message, sender) {
  if (!sender.tab || !isBridgeSite(sender.url ?? "")) throw new Error("Not from Mero Page.");
  const origin = sender.origin ?? new URL(sender.url).origin;

  if (message?.type === "status") {
    const account = await getAccount();
    return { ok: true, connected: Boolean(account), email: account?.email ?? null, version: chrome.runtime.getManifest().version };
  }
  if (message?.type === "connect") {
    if (!new URL(sender.url).pathname.startsWith(CONNECT_PATH.replace(/\/$/, ""))) throw new Error("Connect from the Chrome extension page.");
    return { ok: true, email: await connect({ token: message.token, api: message.api, site: origin }) };
  }
  throw new Error("Unknown message.");
}

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  handle(message, sender).then(reply, (error) => reply({ ok: false, message: error.message }));
  return true;
});
