/**
 * The toolbar popup (also Alt+Shift+S): saves the page in the active tab — on Facebook, Instagram or X, open the post itself
 * first — with an optional title, note, tags and collection. Not connected yet, it sends the person to the site to connect.
 */
import { SignedOut, disconnect, getAccount, getCollections, refreshCollections, saveCapture, siteAddress } from "../account.js";
import { cleanLink, newCapture, pageDetails, parseTags, readPage } from "../capture.js";

const CONNECT_PATH = "/captures/extension/";
const CAPTURES_PATH = "/captures/";

const $ = (id) => document.getElementById(id);

function show(...ids) {
  for (const id of ["connect", "unsavable", "save", "saved", "footer"]) $(id).hidden = !ids.includes(id);
}

function showConnect(reason) {
  $("account").textContent = "";
  $("connect-reason").textContent = reason ?? "";
  $("connect-reason").hidden = !reason;
  show("connect");
}

function fillCollections(names) {
  $("collections").replaceChildren(...names.map((name) => Object.assign(document.createElement("option"), { value: name })));
}

async function readActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let found = null;
  try {
    [{ result: found }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: readPage });
  } catch {
    // A page Chrome keeps extensions out of: the tab's own address and title are all there is.
  }
  return pageDetails(found, tab);
}

async function start() {
  const account = await getAccount();
  if (!account) return showConnect();
  $("account").textContent = account.email;

  const page = await readActiveTab();
  if (!/^https?:\/\//i.test(page.url ?? "")) return show("unsavable", "footer");

  $("title").value = page.title ?? "";
  $("preview-host").textContent = new URL(page.url).hostname.replace(/^www\./, "");
  if (page.image) {
    $("preview-image").src = page.image;
    $("preview-image").hidden = false;
    $("preview-image").addEventListener("error", () => ($("preview-image").hidden = true));
  }
  fillCollections(await getCollections());
  void refreshCollections().then(getCollections).then(fillCollections);
  show("save", "footer");
  $("note").focus();

  $("save").addEventListener("submit", async (event) => {
    event.preventDefault();
    $("save-button").disabled = true;
    $("save-button").textContent = "Saving…";
    $("error").hidden = true;
    try {
      await saveCapture(
        newCapture({
          ...page,
          url: cleanLink(page.url),
          pageUrl: page.url,
          customTitle: $("title").value,
          note: $("note").value,
          tags: parseTags($("tags").value),
          collection: $("collection").value,
        }),
      );
      show("saved", "footer");
    } catch (error) {
      if (error instanceof SignedOut) return showConnect(error.message);
      $("error").textContent = error.message;
      $("error").hidden = false;
    } finally {
      $("save-button").disabled = false;
      $("save-button").textContent = "Save";
    }
  });
}

$("connect-button").addEventListener("click", async () => {
  await chrome.tabs.create({ url: await siteAddress(CONNECT_PATH) });
  window.close();
});

$("open-captures").addEventListener("click", async () => {
  await chrome.tabs.create({ url: await siteAddress(CAPTURES_PATH) });
  window.close();
});

$("disconnect").addEventListener("click", async () => {
  await disconnect();
  showConnect();
});

void start();
