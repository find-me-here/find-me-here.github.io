/**
 * A capture, as `PUT /api/v1/mobile/captures/{id}` takes it — the same shape the phone app sends (see the backend's
 * `SyncLocalCaptureRequest`), so the site's Captures page shows it like any other. Pure, so it is tested in test/.
 */

const VERSION = typeof chrome !== "undefined" && chrome.runtime?.getManifest ? chrome.runtime.getManifest().version : "dev";

/** "#Food, travel  #food" → ["Food", "travel"]: spaces or commas between, a leading # dropped, no repeats whatever the case. */
export function parseTags(input) {
  const seen = new Set();
  const tags = [];
  for (const raw of (input ?? "").split(/[\s,]+/)) {
    const tag = raw.replace(/^#+/, "").trim();
    if (!tag || seen.has(tag.toLowerCase())) continue;
    seen.add(tag.toLowerCase());
    tags.push(tag);
  }
  return tags;
}

const isWebAddress = (url) => /^https?:\/\//i.test(url ?? "");

/** Facebook's and Instagram's wrapper for a link out of the site: the real address is its `u`. */
const REDIRECTORS = new Set(["l.facebook.com", "lm.facebook.com", "l.instagram.com"]);
/** Added to a shared address to track who opened it; never part of what it points at. */
const TRACKING = /^(utm_.+|fbclid|gclid|igshid|igsh|mibextid|__cft__.*|__tn__)$/;
/** X's share parameters (`?s=20&t=…`); elsewhere `t` can be meaningful (a video's start time), so only there. */
const X_HOSTS = new Set(["x.com", "twitter.com"]);

/** The address as it should be kept: out of Facebook's or Instagram's redirect, without tracking parameters. */
export function cleanLink(url) {
  if (!isWebAddress(url)) return url ?? null;
  let parsed = new URL(url);
  const wrapped = REDIRECTORS.has(parsed.hostname) ? parsed.searchParams.get("u") : null;
  if (wrapped && isWebAddress(wrapped)) parsed = new URL(wrapped);
  const host = parsed.hostname.replace(/^(www|mobile)\./, "");
  for (const key of [...parsed.searchParams.keys()]) {
    if (TRACKING.test(key) || (X_HOSTS.has(host) && (key === "s" || key === "t"))) parsed.searchParams.delete(key);
  }
  return parsed.href;
}

const clean = (value, max = 5000) => {
  const text = (value ?? "").replace(/\s+\n/g, "\n").trim();
  return text ? text.slice(0, max) : null;
};

/**
 * Builds the capture.
 * - `url`: what it points at (the post); `title` and `image`: the page's own, which a card shows.
 * - `text`: the words that came with it — a post's text, or what the person selected.
 * - `note`, `tags`, `collection`, `customTitle`: what the person added in the popup. A title the same as the page's is not a note.
 */
export function newCapture({ url, title, image, text, customTitle, note, tags = [], collection, pageUrl, now = Date.now(), id = crypto.randomUUID() }) {
  const webUrl = isWebAddress(url) ? url : null;
  const pageTitle = clean(title, 300);
  const ownTitle = clean(customTitle, 300);
  const description = clean(note);
  const hasNote = Boolean((ownTitle && ownTitle !== pageTitle) || description || tags.length);

  return {
    id,
    body: {
      received_at: now,
      type: webUrl ? "weburl" : "text",
      text: clean(text),
      web_url: webUrl,
      source_app: null,
      meta: pageTitle ? { title: pageTitle } : null,
      raw: { via: "chrome-extension", version: VERSION, ...(pageUrl && pageUrl !== webUrl ? { page_url: pageUrl } : {}) },
      collection: clean(collection, 255) ?? "Unsorted",
      link: webUrl ? { title: pageTitle, image_uri: isWebAddress(image) ? image : null } : null,
      files: [],
      note: hasNote
        ? {
            title: ownTitle && ownTitle !== pageTitle ? ownTitle : "",
            description: description ?? "",
            tags,
            voice: null,
            reminder_at: null,
            reminder_repeat: null,
            updated_at: now,
          }
        : null,
    },
  };
}

/**
 * What to save of the page in the tab, from what `readPage` found. A feed (Facebook, X, Instagram) changes the address
 * without reloading, and leaves the first page's og: tags behind — so they are trusted only when they name this address.
 */
export function pageDetails(found, tab = {}) {
  const url = found?.url ?? tab.url ?? null;
  const samePage = (other) => {
    if (!other || !url) return false;
    try {
      const a = new URL(other, url);
      const b = new URL(url);
      return a.host.replace(/^www\./, "") === b.host.replace(/^www\./, "") && a.pathname.replace(/\/+$/, "") === b.pathname.replace(/\/+$/, "");
    } catch {
      return false;
    }
  };
  const ogTrusted = samePage(found?.ogUrl) || samePage(found?.canonical);

  return {
    url: ogTrusted && isWebAddress(found?.canonical) ? found.canonical : url,
    title: (ogTrusted && found?.ogTitle) || found?.title || tab.title || null,
    image: ogTrusted ? (found?.ogImage ?? null) : null,
    text: found?.selection || (ogTrusted ? found?.ogDescription : null) || null,
  };
}

/** Runs in the page (chrome.scripting): its address, title, og: tags and whatever is selected. Self-contained on purpose. */
export function readPage() {
  const meta = (name) => document.querySelector(`meta[property="${name}"], meta[name="${name}"]`)?.getAttribute("content")?.trim() || null;
  return {
    url: location.href,
    title: document.title?.trim() || null,
    ogTitle: meta("og:title"),
    ogDescription: meta("og:description"),
    ogImage: meta("og:image"),
    ogUrl: meta("og:url"),
    canonical: document.querySelector('link[rel="canonical"]')?.href || null,
    selection: String(window.getSelection() ?? "").trim() || null,
  };
}

/**
 * Runs in the page: the text of the post a link belongs to — the link being a post's time stamp, right-clicked in a feed.
 * Facebook, Instagram and X put a post in an `article`; the text's own element is looked up per site, and nothing is guessed
 * elsewhere (an article's whole text is its buttons and counts as much as its words). Self-contained on purpose.
 */
export function readPost(href) {
  const target = new URL(href, location.href).href;
  const link = [...document.querySelectorAll("a[href]")].find((anchor) => anchor.href === target || anchor.href.split("?")[0] === target.split("?")[0]);
  const post = link?.closest('article, [role="article"]');
  if (!post) return null;
  const host = location.hostname.replace(/^www\./, "");
  const selectors = {
    "x.com": '[data-testid="tweetText"]',
    "twitter.com": '[data-testid="tweetText"]',
    "facebook.com": '[data-ad-preview="message"], [data-ad-comet-preview="message"]',
    "instagram.com": "h1",
  };
  const text = selectors[host] ? post.querySelector(selectors[host])?.innerText?.trim() : null;
  return text || null;
}
