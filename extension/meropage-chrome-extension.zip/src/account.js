/**
 * The account the extension saves to, kept in chrome.storage.local: `{ token, api, site, email }`. The token is the
 * extension's own (`POST /api/v1/extension/token`, asked for by the site's Connect page), never the site's.
 */
import { DEFAULT_SITE, isAllowedConnection } from "./config.js";

/** The API refused the token: it was revoked, or the account is gone. The extension forgets it and asks to connect again. */
export class SignedOut extends Error {}

export async function getAccount() {
  const { account } = await chrome.storage.local.get("account");
  return account ?? null;
}

async function request(account, path, { method = "GET", body } = {}) {
  const response = await fetch(`${account.api}${path}`, {
    method,
    headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${account.token}` },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (response.status === 401) throw new SignedOut("Your Mero Page account was disconnected. Connect it again.");
  if (response.status === 204) return null;
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message ?? `Mero Page answered ${response.status}. Try again.`);
  return data;
}

/** Signs the extension in with a token from the Connect page, after checking it works and whose it is. */
export async function connect({ token, api, site }) {
  if (typeof token !== "string" || !token || !isAllowedConnection(site, api)) throw new Error("That sign-in can’t be used here.");
  const account = { token, api: api.replace(/\/+$/, ""), site: new URL(site).origin };
  const { data: user } = await request(account, "/v1/user");
  const previous = await getAccount();
  // Connecting again (or as someone else) leaves the old token unused: revoke it.
  if (previous && previous.token !== token) request(previous, "/v1/extension/token", { method: "DELETE" }).catch(() => {});
  await chrome.storage.local.set({ account: { ...account, email: user.email }, collections: [] });
  void refreshCollections();
  return user.email;
}

export async function disconnect() {
  const account = await getAccount();
  await chrome.storage.local.remove(["account", "collections"]);
  if (account) await request(account, "/v1/extension/token", { method: "DELETE" }).catch(() => {});
}

/** Saves a capture from `newCapture`. A refused token signs the extension out. */
export async function saveCapture({ id, body }) {
  const account = await getAccount();
  if (!account) throw new SignedOut("Connect your Mero Page account first.");
  try {
    await request(account, `/v1/mobile/captures/${encodeURIComponent(id)}`, { method: "PUT", body });
  } catch (error) {
    if (error instanceof SignedOut) await chrome.storage.local.remove(["account", "collections"]);
    throw error;
  }
  if (body.collection) await rememberCollection(body.collection);
}

/** The collections the person already uses, for the popup's suggestions. */
export async function getCollections() {
  const { collections } = await chrome.storage.local.get("collections");
  return collections ?? [];
}

async function rememberCollection(name) {
  const collections = await getCollections();
  if (!collections.includes(name)) await chrome.storage.local.set({ collections: [...collections, name].sort((a, b) => a.localeCompare(b)) });
}

/** Reads them afresh from the person's captures. Best effort: the suggestions just stay as they were. */
export async function refreshCollections() {
  const account = await getAccount();
  if (!account) return;
  try {
    const { data } = await request(account, "/v1/mobile/captures");
    const names = [...new Set(data.map((capture) => capture.collection).filter(Boolean))].sort((a, b) => a.localeCompare(b));
    await chrome.storage.local.set({ collections: names });
  } catch {
    // Offline, or signed out: nothing to suggest from.
  }
}

/** The site's page for connecting, or the person's captures once connected. */
export async function siteAddress(path) {
  const account = await getAccount();
  return `${account?.site ?? DEFAULT_SITE}${path}`;
}
