/**
 * Where the extension's account lives. It is connected from the site's "Connect" page (/captures/extension), which hands
 * it a token and the API that token belongs to; only the pairs below are accepted, so no page can point the extension at
 * a server of its own.
 */

/** The site the popup sends people to, to connect or to read their captures. */
export const DEFAULT_SITE = "https://www.meropage.com";

const PRODUCTION_SITES = ["https://www.meropage.com", "https://meropage.com"];
const PRODUCTION_API = "https://api.meropage.com/api";

/** A checkout running on this computer: `next dev` on localhost, a Laravel site on a `.test` or `.local` name. */
function isLocal(url) {
  const { hostname } = new URL(url);
  return hostname === "localhost" || hostname === "127.0.0.1" || hostname.endsWith(".test") || hostname.endsWith(".local");
}

/**
 * Whether a token from `site` may be used against `api`: the live site with the live API, or a local checkout with a local
 * API (the content script only runs on localhost in the unpacked extension — `scripts/pack.mjs` drops it from the zip).
 */
export function isAllowedConnection(site, api) {
  try {
    const siteOrigin = new URL(site).origin;
    const apiUrl = new URL(api);
    if (!["http:", "https:"].includes(apiUrl.protocol)) return false;
    if (PRODUCTION_SITES.includes(siteOrigin)) return api.replace(/\/+$/, "") === PRODUCTION_API;
    return isLocal(siteOrigin) && isLocal(apiUrl.href);
  } catch {
    return false;
  }
}

/** A site the bridge (src/bridge.js) may speak for. */
export function isBridgeSite(url) {
  try {
    const origin = new URL(url).origin;
    return PRODUCTION_SITES.includes(origin) || isLocal(origin);
  } catch {
    return false;
  }
}
